#pragma once

#include "ofMain.h"
#include "ofxOsc.h"

class VolcanStaturInformer {
public:
	// Metodos
	void setup(const std::string &, int);
	void informTransitionStatus();
	void informDespiertoStatus();
	void informDormidoStatus();

private:

	// Fields
	ofxOscSender sender;
};